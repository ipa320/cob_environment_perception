/*
 * registration_rgbdslam.h
 *
 *  Created on: Nov 15, 2011
 *      Author: goa-jh
 */

#ifndef REGISTRATION_RGBDSLAM_H_
#define REGISTRATION_RGBDSLAM_H_

#include "general_registration.h"
#include <pcl/point_cloud.h>

//template <typename Point>
class Registration_ICP : public Registration_RGBDSLAM<Point>
{
  typedef pcl::PointXYZ Point;
public:
  Registration_RGBDSLAM():
    non_linear_(false),
    icp_max_iterations_(50),
    icp_max_corr_dist_(0.05),
    icp_trf_epsilon_(0.0001),
    outlier_rejection_threshold_(0.01)
  {}

  void setNonLinear(bool b) {non_linear_=b;}
  pcl::PointCloud<Point> &getMap() {return register_;}

  void setMaxIterations(int v) {icp_max_iterations_=v;}
  void setCorrDist(float v) {icp_max_corr_dist_=v;}
  void setTrfEpsilon(float v) {icp_trf_epsilon_=v;}
  void setOutlierRejectionThreshold(float v) {outlier_rejection_threshold_=v;}

protected:

  virtual bool compute_features();
  virtual bool compute_corrospondences();
  virtual bool compute_transformation();

  virtual void setSettingsForICP(ModifiedICP<Point> &icp);

  //internal states
  pcl::PointCloud<Point> register_;

  // parameters
  int icp_max_iterations_;
  float icp_max_corr_dist_,
  outlier_rejection_threshold_,
  icp_trf_epsilon_;
  bool non_linear_;
};


#endif /* REGISTRATION_RGBDSLAM_H_ */
