/****************************************************************
 *
 * Copyright (c) 2011
 *
 * Fraunhofer Institute for Manufacturing Engineering
 * and Automation (IPA)
 *
 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *
 * Project name: care-o-bot
 * ROS stack name: cob_vision
 * ROS package name: dynamic_tutorials
 * Description:
 *
 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *
 * Author: goa-jh
 * Supervised by: Georg Arbeiter, email:georg.arbeiter@ipa.fhg.de
 *
 * Date of creation: Oct 26, 2011
 * ToDo:
 *
 *
 *
 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Fraunhofer Institute for Manufacturing
 *       Engineering and Automation (IPA) nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License LGPL as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License LGPL for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License LGPL along with this program.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 ****************************************************************/

#ifndef REGISTRATION_ICP_H_
#define REGISTRATION_ICP_H_

#include "general_registration.h"
#include "impl/modified_icp.hpp"
#include "feature_container.h"
#include <pcl/point_cloud.h>

template <typename Point>
class Registration_ICP : public GeneralRegistration<Point>
{
public:
  Registration_ICP():
    non_linear_(false),
    icp_max_iterations_(50),
    icp_max_corr_dist_(0.05),
    icp_trf_epsilon_(0.0001),
    outlier_rejection_threshold_(0.01)
  {}

  void setNonLinear(bool b) {non_linear_=b;}
  virtual pcl::PointCloud<Point> &getMap() {return register_;}

  void setMaxIterations(int v) {icp_max_iterations_=v;}
  void setCorrDist(float v) {icp_max_corr_dist_=v;}
  void setTrfEpsilon(float v) {icp_trf_epsilon_=v;}
  void setOutlierRejectionThreshold(float v) {outlier_rejection_threshold_=v;}

protected:

  virtual bool compute_features();
  virtual bool compute_corrospondences();
  virtual bool compute_transformation();

  virtual void setSettingsForICP(ModifiedICP<Point> &icp);

  //internal states
  pcl::PointCloud<Point> register_;

  // parameters
  int icp_max_iterations_;
  float icp_max_corr_dist_,
  outlier_rejection_threshold_,
  icp_trf_epsilon_;
  bool non_linear_;
};

template <typename Point>
class Registration_ICP_Features : public Registration_ICP<Point>
{
public:
  void setFeatures(FeatureContainerInterface* features) {features_ = features;}
protected:

  FeatureContainerInterface* features_;

  virtual void setSettingsForICP(ModifiedICP<Point> &icp);
};

template <typename Point, typename FeatureType>
class Registration_ICP_Features_Extra : public Registration_ICP_Features<Point>
{
public:
  //virtual bool calculateFeature(pcl::PointCloud<Point>::Ptr input, pcl::PointCloud<Point>::Ptr output, pcl::PointCloud<FeatureType>::Ptr features);
  virtual bool calculateFeature(boost::shared_ptr<pcl::PointCloud<Point> > input, boost::shared_ptr<pcl::PointCloud<Point> > output, boost::shared_ptr<pcl::PointCloud<FeatureType> > features);
protected:
  virtual bool compute_features();
};



#include "impl/registration_icp.hpp"

#endif
